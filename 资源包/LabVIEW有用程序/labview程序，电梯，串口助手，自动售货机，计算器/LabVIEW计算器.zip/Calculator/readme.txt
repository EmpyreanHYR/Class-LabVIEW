The Calculator VI is a fully-functional calculator built in LabVIEW.  It demonstrates the following concepts taught in the LabVIEW Basics class.

- Dataflow Programming
- Modular Programming
- While Loops
- Shift Registers
- Case Structures
- Functional Global Variables
- Event-Driven Programming
- VI Documentation
- Control/Indicator Documentation
- Custom Controls/Type Definitions
- Passing References
- Property  Nodes
- LabVIEW Project and Application Builder

Author: Erik Johnson, National Instruments