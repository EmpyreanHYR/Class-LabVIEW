LVBarcode
Google Project - http://code.google.com/p/lvbarcode/

2007/09/04 1st version release.
2007/12/26 fix some bugs.
