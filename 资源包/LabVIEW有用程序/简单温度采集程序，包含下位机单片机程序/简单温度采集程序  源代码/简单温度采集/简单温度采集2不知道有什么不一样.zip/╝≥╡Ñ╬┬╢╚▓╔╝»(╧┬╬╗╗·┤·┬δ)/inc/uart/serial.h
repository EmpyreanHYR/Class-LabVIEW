#ifndef __SERIAL_H__
#define __SERIAL_H__

//#include <string.h>


void serial_init(void);
void serial_tc (unsigned char *str);
void serial_t (unsigned char serial_data);










#endif


































